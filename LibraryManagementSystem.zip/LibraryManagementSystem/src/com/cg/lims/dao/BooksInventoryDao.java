package com.cg.lims.dao;

import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.bean.BooksInventory;

public interface BooksInventoryDao
{
	public int addBookInventory(BooksInventory bookInv) throws BookInventoryException;
	public String generateBookId() throws BookInventoryException;
	public int deleteBook(String bId) throws BookInventoryException;
}
