package com.cg.lims.dao;



import java.util.ArrayList;

import com.cg.lims.Exception.UserException;

public interface UserDao 
{
	public ArrayList<String> getUserName()throws Exception, UserException;
	public ArrayList<String> getUserPwd()throws Exception, UserException;
	public String getLibrarianValueByUserName(String userName) throws UserException;
}
