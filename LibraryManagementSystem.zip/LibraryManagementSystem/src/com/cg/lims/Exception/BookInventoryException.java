package com.cg.lims.Exception;

public class BookInventoryException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookInventoryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookInventoryException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BookInventoryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BookInventoryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BookInventoryException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
