package com.cg.lims.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.dao.BooksTransactionDao;
import com.cg.lims.dao.BooksTransactionDaoImpl;

public class BooksTransactionServiceImpl implements BooksTransactionService
{
	BooksTransactionDao bookTransactionDao;
	public BooksTransactionServiceImpl()
	{
		bookTransactionDao=new BooksTransactionDaoImpl();
	}

	@Override
	public String generateTransactionId() throws BooksTransactionException 
	{	
		return bookTransactionDao.generateTransactionId();		
	}

	@Override
	public ArrayList<String> getRegId() throws RegistrationException 
	{
		return bookTransactionDao.getRegId();
	}

	@Override
	public int issueBook(BookTransaction bookTransaction) throws BooksTransactionException 
	{		
		return bookTransactionDao.issueBook(bookTransaction);
	}

	@Override
	public boolean validateRegId(String RegId) throws RegistrationException 
	{

		ArrayList<String> regIds=bookTransactionDao.getRegId();
		int flag=0;
		for(String tempbookIds :regIds)
		{
			if(RegId.equals(tempbookIds))
			{
				flag=1;
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Invalid Registration Id. Please check it");
		}
	}

	@Override
	public Date getReturnDate(String transactionId)
			throws BooksTransactionException 
	{
		
		return bookTransactionDao.getReturnDate(transactionId);
	}

	@Override
	public int updateReturnDateAndFine(String transactionId, int fine)
			throws BooksTransactionException 
	{		
		return bookTransactionDao.updateReturnDateAndFine(transactionId, fine);
	}

	@Override
	public int calculateFine(String transactionId) 
	{
		LocalDate currentDate=LocalDate.now();
		//Date currDate=Date.valueOf(currentDate);
		LocalDate returnDate=null ;
		int fine=0;
		try 
		{
			returnDate = bookTransactionDao.getReturnDate(transactionId).toLocalDate();
			if(currentDate.getDayOfYear()>returnDate.getDayOfYear())
			{
				fine=1*(currentDate.getDayOfYear()-returnDate.getDayOfYear());
			}
		} 
		catch (BooksTransactionException e)
		{
			e.printStackTrace();
		}		
		return fine;
	}


}
