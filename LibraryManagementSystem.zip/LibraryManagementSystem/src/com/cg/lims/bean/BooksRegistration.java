package com.cg.lims.bean;

import java.time.LocalDate;

public class BooksRegistration 
{
	private String registrationId;
	private String bookId;
	private String userId;
	private LocalDate registrationDate;
	public BooksRegistration()
	{
		super();
		
	}
	public BooksRegistration(String registrationId, String bookId,
			String userId, LocalDate registrationDate) 
	{
		super();
		this.registrationId = registrationId;
		this.bookId = bookId;
		this.userId = userId;
		this.registrationDate = registrationDate;
	}
	public String getRegistrationId() 
	{
		return registrationId;
	}
	public void setRegistrationId(String registrationId) 
	{
		
		this.registrationId = registrationId;
	}
	public String getBookId()
	{
		return bookId;
	}
	public void setBookId(String bookId) 
	{
		this.bookId = bookId;
	}
	public String getUserId() 
	{
		return userId;
	}
	public void setUserId(String userId) 
	{
		this.userId = userId;
	}
	public LocalDate getRegistrationDate()
	{
		return registrationDate;
	}
	public void setRegistrationDate(LocalDate registrationDate)
	{
		this.registrationDate = registrationDate;
	}
	@Override
	public String toString()
	{
		return "BooksRegistration [registrationId=" + registrationId
				+ ", bookId=" + bookId + ", userId=" + userId
				+ ", registrationDate=" + registrationDate + "]";
	}
	
}
