package com.cg.dto;

import java.util.List;

public class Employee {
	int empId;
	String empName;
	double sal;
	String buisUnit;
	int age;
	
	List<SBU> s;
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public String getBuisUnit() {
		return buisUnit;
	}
	public void setBuisUnit(String buisUnit) {
		this.buisUnit = buisUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<SBU> getS() {
		return s;
	}
	public void setS(List<SBU> s) {
		this.s = s;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName, double sal, String buisUnit,
			int age) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.sal = sal;
		this.buisUnit = buisUnit;
		this.age = age;
	}
	
	
	public void printDetails()
	{
		System.out.println("Employee Details:");
		System.out.println("Emp id :"+empId);
		System.out.println("Emp name :"+empName);
		System.out.println("Emp salary :"+sal);
		System.out.println("Emp bu :"+buisUnit);
		System.out.println("Emp age :"+age);
		System.out.println("SBU info is"+s.toString());
	}
	

}
